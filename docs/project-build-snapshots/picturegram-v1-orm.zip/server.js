/* this is our server file that will give us all the cool stuff we need */
const express = require( 'express' );
const PORT = process.env.PORT || 8080;

const orm = require( './orm' );

const app = express();

app.use( express.static('html') );
app.use( express.urlencoded({ extended: false }) );

app.get( '/api/thumbnails', async function( req, res ){
    const myPictureList = await orm.listThumbnails();

    res.send( myPictureList );
});

app.post( '/api/thumbnails', async function( req, res ){
    console.log( `[POST api/thumbnails] recieved: `, req.body );
    await orm.saveThumbnail( req.body );

    res.send( { message: `Thank you, saved ${req.body.name}` } );
} );

app.listen( PORT, function(){
    console.log( `[pictures] RUNNING, http://localhost:${PORT}` );
})