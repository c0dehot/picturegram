# schema.sql
CREATE database pictures;
USE pictures;

CREATE TABLE thumbnails (
	id INTEGER AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    tags VARCHAR(255) NOT NULL,
    creation_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    update_time DATETIME ON UPDATE CURRENT_TIMESTAMP
);


# seed.sql
INSERT INTO thumbnails (name,image_url,tags) VALUES('Dude','https://cdn.quotesgram.com/img/70/46/2076036230-omg-shocked-dog.jpg','shocked,confused,drooling');

INSERT INTO thumbnails (name,image_url,tags) VALUES('Cleo','https://slacktiverse.files.wordpress.com/2013/03/fuzzy-white-kitten-with-stubby-legs-from-sam_ayye-sam-pertsas.jpg', 'cute,innocent,bleached');

